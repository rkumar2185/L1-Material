package com.cg.xyz.dao;

import com.cg.xyz.beans.Account;

public interface  AccountDao {

	void createdb(String username,Account user);
	String showbal(String username1);

	void deposit(String username1,double depamount);

	void withdraw(String username1,double withamount);

	void transfer(String username1,String username2,double amount);

	void prevtransaction(String username1);

}
