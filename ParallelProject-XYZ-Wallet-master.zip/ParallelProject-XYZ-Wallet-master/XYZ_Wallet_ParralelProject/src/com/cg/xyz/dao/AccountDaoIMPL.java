package com.cg.xyz.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import com.cg.xyz.beans.Account;

public class AccountDaoIMPL implements AccountDao{

	public static HashMap<String, Account> userdetails = new HashMap<>();
	{	
		Date dob2;
		try {
			//bydefault accounts with Rs 100 as initial money
			dob2 = new SimpleDateFormat("dd/MM/yyyy").parse("28/02/1996");
			userdetails.put("akshaysh", new Account("Akshay Sachan","7206301317","akshayshn@gmail.com",dob2,"akshaysh", "abcd.1234"));
			userdetails.get("akshaysh").setBalance((double) 100,3);
			
			dob2 = new SimpleDateFormat("dd/MM/yyyy").parse("28/02/1993");
			userdetails.put("vaishali", new Account("Vaishali Kumari","9928721645","vaishali@gmail.com",dob2,"vaishali", "vais.1234"));
			userdetails.get("vaishali").setBalance((double) 100,3);
		} catch (ParseException e) {}
		
	}
	public void createdb(String username,Account user) 
	{
		userdetails.put(username, user);
	}
	@Override
	public String showbal(String username1) {
		
		return ("Hello: "+(String)userdetails.get(username1).getName()+", Your Balance is: "+userdetails.get(username1).getBalance());
		
		}
	@Override
	public void deposit(String username1,double depamount) {
		
		double initialamt=userdetails.get(username1).getBalance();
		userdetails.get(username1).setBalance(initialamt+depamount,3);
				
		}
	@Override
	public void withdraw(String username1,double withamount) {
		
		double initialamt=userdetails.get(username1).getBalance();
		userdetails.get(username1).setBalance(initialamt-withamount,1);
			
		}
	@Override
	public void transfer(String username1,String username2,double amount) {
		double initialamt1=userdetails.get(username1).getBalance();
		userdetails.get(username1).setBalance(initialamt1-amount,2);
		double initialamt2=userdetails.get(username2).getBalance();
		userdetails.get(username2).setBalance(initialamt2+amount,3);
		
	}
	@Override
	public void prevtransaction(String username1) {
		int size=userdetails.get(username1).transaction().size();
		System.out.println("Following is the transaction history:");
		for(int i = 0; i <(size>5?5:size); i++) {   
		    System.out.println("\t"+userdetails.get(username1).transaction().get(i));
			} 
		
		
	}

	
	

}
