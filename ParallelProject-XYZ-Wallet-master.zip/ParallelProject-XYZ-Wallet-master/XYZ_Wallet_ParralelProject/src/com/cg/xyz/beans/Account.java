package com.cg.xyz.beans;

import java.util.ArrayList;
import java.util.Date;


public class Account {
	String name;
	String username;
	String password;
	String mobNo;
	String email;
	Date dob;
	double balance;
	ArrayList<String> transactiondata = new ArrayList<>();

	public Account(String name, String mobNo, String email, Date dob2,String username, String password) {

		this.name = name;
		this.mobNo = mobNo;
		this.email = email;
		this.dob = dob2;
		this.username = username;
		this.password = password;
		
	}
	public ArrayList<String> transaction()
	{
		 
		    return(transactiondata);
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public double getBalance() {
		return balance;
	}
	public void setBalance(Double bal,int c) {
		if(c==1)
		transactiondata.add("Withdrawn Rs. "+(balance-bal));
		if(c==2)
		transactiondata.add("Transferred Rs. "+(balance-bal));
		if(c==3)
		transactiondata.add("Deposited Rs. "+ (bal-balance));
		this.balance = bal;
	}

}
