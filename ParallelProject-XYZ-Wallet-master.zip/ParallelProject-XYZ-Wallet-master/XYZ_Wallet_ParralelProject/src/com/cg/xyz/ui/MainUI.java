package com.cg.xyz.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import com.cg.xyz.beans.Account;
import com.cg.xyz.excpetion.AmountCheckException;
import com.cg.xyz.excpetion.Emailexception;
import com.cg.xyz.excpetion.Mobilenoexception;
import com.cg.xyz.excpetion.Passwordexception;
import com.cg.xyz.excpetion.UserIDexception;
import com.cg.xyz.excpetion.Usernameexception;
import com.cg.xyz.service.AccountService;
import com.cg.xyz.service.AccountServiceIMPL;


public class MainUI {
	static Scanner sc;
public static void main(String[] args)
{
	
	AccountService aser=new AccountServiceIMPL();
	sc = new Scanner(System.in);
	String username,mobileNo,email,password,name; Date dateofbirth;
	do
	{
	System.out.println("******Welcome to XYZ Wallet.****** \n\nMenu");
	System.out.println("1. Create Account");
	System.out.println("2. Login to Account");
	System.out.println("3. Exit Application\n");
	
	System.out.println("Enter your choice: ");
	int choice = sc.nextInt();
	
	switch(choice)
	{
	case 1:
		while(true)
		{
		System.out.println("Enter the Name : ");
		sc.nextLine();
		name=sc.nextLine();
		try
		{
			if(aser.validateName(name));
			break;
		}catch(Usernameexception e) {}
		}
		
		while(true)
		{
			System.out.println("Enter the UserID consisting of 8 characters: ");
			username=sc.nextLine();
			
			try
			{
				if(!aser.validateUserID(username));
				break;
			}catch(UserIDexception e) {}
		}	
		
		while(true)
		{
			System.out.println("Enter the Mobile No : ");
			mobileNo = sc.nextLine();
			
			
			try
			{
				if(aser.validateMobileno(mobileNo,username));
				break;
			}catch(Mobilenoexception e) {}
			
		}
		while(true)
		{
			System.out.println("Enter the Email Address : ");
			email=sc.nextLine();
		
			try {
				if(!aser.validateEmailexist(email));
				break;
				} catch (Emailexception e1) {   }
				
		}
		while(true)
		{
		System.out.println("Enter the Date of Birth in dd/mm/yyyy: ");
		String dob=sc.nextLine();
		
						
		try {
				dateofbirth = new SimpleDateFormat("dd/MM/yyyy").parse(dob);
				break;
			} catch (ParseException e2) {
				System.out.println("Please enter correct Date of Birth.\n");
				}
		}
		while(true)
		{
			System.out.println("Enter the Password having total 9 characters including atleast a character, a special character and a number: ");
			password=sc.nextLine();
				try
				{
					if(aser.validatePassword(password));
					break;
				
				}catch (Passwordexception e1) {}
			
		}
		Account Custdetails = new Account(name, mobileNo, email,dateofbirth,username,password);
		aser.createdb(username, Custdetails);
		System.out.println("You have successfully created your Account");
		break;
		
		
	case 2: 
		
		System.out.println("Please Enter the UserName: ");
		sc.nextLine();
		String username1=sc.nextLine();
		
		System.out.println("Please Enter the Password: ");
		String password1=sc.nextLine();
		
		
		try 
		{
			int choice1;
			if(aser.validateAccount(username1,password1));
				do
			{
				System.out.println("Menu\n	1. Show Balance");
				System.out.println("	2. Deposit");
				System.out.println("	3. Withdraw");
				System.out.println("	4. Fund Transfer");
				System.out.println("	5. Print Transactions");
				System.out.println("	6. Logout\nEnter your choice:");
				choice1=sc.nextInt();
				switch(choice1)
				{
					case 1:
						System.out.println(aser.showbal(username1));break;
					case 2:
						System.out.println("Enter the Amount to be Deposit");
						double amount=sc.nextDouble();
						try {
						aser.deposit(username1,amount);
						System.out.println("Amount Successfully Deposited");
						System.out.println("\n"+aser.showbal(username1));
						} catch (AmountCheckException e) {
							
						}
						break;
					case 3:
						System.out.println("Enter the Amount to be Withdrawn");
						double amt=sc.nextDouble();
					try {
						aser.withdraw(username1,amt);
						System.out.println("Amount Successfully Withdrawn");
						System.out.println("\n"+aser.showbal(username1));
					} catch (AmountCheckException e) {
						
					}
						
						break;
					case 4:
						System.out.println("Enter the username to whom you want to transfer the amount");
						sc.nextLine();
						String username2=sc.nextLine();
						System.out.println("Enter the amount to transfer");
						double amt2=sc.nextDouble();
						try {
						aser.transfer(username1,username2,amt2);
						System.out.println("Amount Successfully Transferred");
						System.out.println("\n"+aser.showbal(username1));
						}catch(UserIDexception u) {}
						catch(AmountCheckException a) {}
						
						break;
					case 5:
						aser.prevtransaction(username1);
						break;
					case 6: 
						System.out.println("You have Succesfully Logout");
						break;
					default:
						System.out.println("Invalid Choice");
				
				}
			}while(choice1!=6);
				
		} catch (UserIDexception e) {
			
		}catch (Passwordexception e) {}
			
		break;
	case 3: 
		
		System.out.println("\nThanks for using the Application, We are pleased to have you. :D");
		System.exit(0);
	default:
		System.out.println("Invalid Choice");
	}
}while(true);
}
}


