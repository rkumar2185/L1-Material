package com.cg.xyz.service;
import java.util.Map;

import com.cg.xyz.beans.Account;
import com.cg.xyz.dao.AccountDao;
import com.cg.xyz.dao.AccountDaoIMPL;
import com.cg.xyz.excpetion.AmountCheckException;
import com.cg.xyz.excpetion.Emailexception;
import com.cg.xyz.excpetion.Mobilenoexception;
import com.cg.xyz.excpetion.Passwordexception;
import com.cg.xyz.excpetion.UserIDexception;
import com.cg.xyz.excpetion.Usernameexception;

public class AccountServiceIMPL implements AccountService {
	
	AccountDao adao=new AccountDaoIMPL();
	
	@Override
	public void createdb(String username,Account user) {
		adao.createdb(username,user);
		
	}

	@Override
	public boolean validateAccount(String username1, String password1) throws Passwordexception, UserIDexception 
	{
		if(AccountDaoIMPL.userdetails.containsKey(username1))
		{
			if(AccountDaoIMPL.userdetails.get(username1).getPassword().equals(password1))
				return true;
			else throw new  Passwordexception("ERROR:  Given Password Does Not Matches with username: "+username1+"\n");
		}
		else
		throw new  UserIDexception("ERROR:  Given Username: "+username1+" Does Not Matches with database\n");
		
	}

	@Override
	public String showbal(String username1) {
		return adao.showbal(username1);
		
	}

	@Override
	public void deposit(String username1,double depamount) throws AmountCheckException {
		if(depamount<1)
			throw new AmountCheckException("Min balance you can deposit is Rs 1.\n");
		else
		adao.deposit(username1,depamount);
		
	}

	@Override
	public void withdraw(String username1,double withamount) throws AmountCheckException {
		if(AccountDaoIMPL.userdetails.get(username1).getBalance()<withamount)
			throw new AmountCheckException("You cannot withdraw more than Rs "+AccountDaoIMPL.userdetails.get(username1).getBalance()+"\n");
		else
			adao.withdraw(username1,withamount);
		
	}

	@Override
	public void transfer(String username1,String username2,double amount) throws UserIDexception, AmountCheckException 
	{
		if(!AccountDaoIMPL.userdetails.containsKey(username2))
			throw new UserIDexception("ERROR:  Given Username: "+username2+" Does Not Matches with database\n");
		else 
		{
			if((AccountDaoIMPL.userdetails.get(username1).getBalance()<amount))
			throw new AmountCheckException("You cannot transfer more than Rs "+AccountDaoIMPL.userdetails.get(username1).getBalance());
		else {
				adao.transfer(username1,username2,amount);
			 }
		}
	}

	@Override
	public void prevtransaction(String username1) {
		adao.prevtransaction(username1);
		
	}

	@Override
	public boolean validatePassword(String password) throws Passwordexception {
		if(!password.matches("[A-Za-z0-9!@#$%^&*()_.]{9,9}"))
		{
			throw new Passwordexception("Password should have total 9 characters including atleast a character, a special character and a number\n");
		}
		return true;
		
	}

	@Override
	public void validateEmail(String email) throws Emailexception {
		if(!email.matches("[A-Za-z0-9]{3,9}[@]{1}[A-Za-z]{2,7}[.]{1}[a-z]{2,6}"))
		{
			throw new Emailexception(email+" Email is not correct.\n");
		}
		
	}

	@Override
	public boolean validateUserID(String username) throws UserIDexception {
		if(username.length()!=8)
		{
			throw new UserIDexception("Sorry, The UserID: "+username+" entered  is not of 8 characters length. Try Again\n ");
		}
		else if(!AccountDaoIMPL.userdetails.containsKey(username))
			return true;
		else
			throw new UserIDexception("Sorry, The UserID: "+username+" already exist. Try Again\n ");
			
	}

	@Override
	public boolean validateMobileno(String mobileNo,String username) throws Mobilenoexception   {
		
		if(mobileNo.length()!=10||mobileNo.matches("[A-Za-z]"))
		{	
			throw new Mobilenoexception("Mobile Number: "+mobileNo+" length is not corrent, please enter correct Mobile Number\n");
			
		}
		
		else {
		for(Map.Entry<String, Account> m:AccountDaoIMPL.userdetails.entrySet())
		{
			if(m.getValue().getMobNo().matches(mobileNo))
				throw new Mobilenoexception("Sorry, The Mobile Number: "+mobileNo+" entered already exist with another UserID. Try Again\n ");
		}
		}
		 return true;
			
	}

	@Override
	public boolean validateEmailexist(String email) throws Emailexception {
		for(Map.Entry<String, Account> m:AccountDaoIMPL.userdetails.entrySet())
		{
			if(m.getValue().getEmail().matches(email))
				throw new Emailexception("Sorry, The Email: "+email+" entered already exist with another UserID. Try Again\n ");
		}
		 return true;
	}

	@Override
	public boolean validateName(String name) throws Usernameexception {
		if(!name.matches("[A-Z]{1}[a-z]{2,10}[' ']{1}[A-Z]{1}[a-z]{2,10}"))
			
		{
			throw new Usernameexception("User First and Last Name should start with a capital letter and each length should be a maximum of 10 characters.\n");
		}
		return true;

	}

}
