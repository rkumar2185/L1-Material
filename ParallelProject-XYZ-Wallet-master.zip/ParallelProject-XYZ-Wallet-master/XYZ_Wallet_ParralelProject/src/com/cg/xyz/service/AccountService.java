package com.cg.xyz.service;

import com.cg.xyz.beans.Account;
import com.cg.xyz.excpetion.AmountCheckException;
import com.cg.xyz.excpetion.Emailexception;
import com.cg.xyz.excpetion.Mobilenoexception;
import com.cg.xyz.excpetion.Passwordexception;
import com.cg.xyz.excpetion.UserIDexception;
import com.cg.xyz.excpetion.Usernameexception;

public interface AccountService {
	void createdb(String username,Account user);

	boolean validateAccount(String username1, String password1) throws Passwordexception, UserIDexception;

	String showbal(String username1);

	void deposit(String username1,double depamount) throws AmountCheckException;

	void withdraw(String username1,double withamount) throws AmountCheckException;

	void transfer(String username1,String username2, double amount) throws UserIDexception, AmountCheckException;

	void prevtransaction(String username1);

	boolean validatePassword(String password) throws Passwordexception;

	void validateEmail(String email) throws Emailexception;

	boolean validateUserID(String username) throws  UserIDexception;

	boolean validateMobileno(String mobileNo,String username) throws Mobilenoexception;

	boolean validateEmailexist(String email) throws Emailexception;

	boolean validateName(String name) throws Usernameexception;

	

}
