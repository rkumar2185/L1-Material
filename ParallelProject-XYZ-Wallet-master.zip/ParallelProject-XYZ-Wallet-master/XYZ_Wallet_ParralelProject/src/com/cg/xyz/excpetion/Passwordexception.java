package com.cg.xyz.excpetion;

public class Passwordexception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Passwordexception(String string) {
		System.out.println(string);
	}

}
