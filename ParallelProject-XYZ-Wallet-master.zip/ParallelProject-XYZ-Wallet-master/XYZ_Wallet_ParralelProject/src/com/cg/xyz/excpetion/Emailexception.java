package com.cg.xyz.excpetion;

public class Emailexception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Emailexception(String string) {
		System.out.println(string);
	}

}
