package com.cg.xyz.excpetion;

public class Mobilenoexception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Mobilenoexception(String string) {
		System.out.println(string);
	}

}
