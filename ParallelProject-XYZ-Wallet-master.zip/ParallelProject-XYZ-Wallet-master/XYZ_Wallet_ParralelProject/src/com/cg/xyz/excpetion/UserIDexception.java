package com.cg.xyz.excpetion;

public class UserIDexception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserIDexception(String string) {
		System.out.println(string);
	}

}
