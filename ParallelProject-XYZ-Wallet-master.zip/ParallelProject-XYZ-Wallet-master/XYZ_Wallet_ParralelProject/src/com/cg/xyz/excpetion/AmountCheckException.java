package com.cg.xyz.excpetion;

public class AmountCheckException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AmountCheckException(String string) {
		System.out.println(string);
	}

}
