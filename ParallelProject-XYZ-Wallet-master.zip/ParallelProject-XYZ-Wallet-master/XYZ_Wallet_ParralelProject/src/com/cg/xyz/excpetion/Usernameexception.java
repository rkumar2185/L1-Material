package com.cg.xyz.excpetion;

public class Usernameexception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Usernameexception(String string) {
		System.out.println(string);
	}

}
