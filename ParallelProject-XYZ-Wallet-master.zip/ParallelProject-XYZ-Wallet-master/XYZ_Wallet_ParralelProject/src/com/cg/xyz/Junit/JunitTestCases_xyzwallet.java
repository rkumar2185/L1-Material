package com.cg.xyz.Junit;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.cg.xyz.dao.AccountDaoIMPL;
import com.cg.xyz.excpetion.AmountCheckException;
import com.cg.xyz.excpetion.Emailexception;
import com.cg.xyz.excpetion.Mobilenoexception;
import com.cg.xyz.excpetion.Passwordexception;
import com.cg.xyz.excpetion.UserIDexception;
import com.cg.xyz.excpetion.Usernameexception;
import com.cg.xyz.service.AccountServiceIMPL;
import com.cg.xyz.ui.MainUI;

public class JunitTestCases_xyzwallet {

	MainUI testforUI=new MainUI();
	AccountServiceIMPL testforservice= new AccountServiceIMPL();
	
	@Test
	public void testforName1() {
		
		try {
			assertTrue(testforservice.validateName("Narendra Modi"));
		} catch (Usernameexception e) {}
	}
		
	@Test
	public void testforName2() {
		
		try {
			assertFalse(testforservice.validateName("narendra Modi"));
		} catch (Usernameexception e) {}
				
	}
	
	@Test
	public void testforEmail1() {
		boolean t=false;
		try {
			testforservice.validateEmail("usadhas");
		} catch (Emailexception e) {
			t=true;
		}
		assertTrue(t);
		
	}
	
	@Test
	public void testforEmail2() {
		boolean t=true;
		try {
			testforservice.validateEmail("akshayshn@gmail.com");
		} catch (Emailexception e) {
			t=false;
		}
		assertTrue(t);
	}
	
	@Test
	public void testforEmail3() {
		
		try {
			assertTrue(testforservice.validateEmailexist("akshayshn@gmail.com"));
		} catch (Emailexception e) {
			
		}
		
	}
	
	@Test
	public void testforUserID1() {
		boolean t=false;
		try {
			//Narendra Modi UserID doesn't exist but its length is greater than 8 and it contains spaces.
			//hence exception is successfully thrown
			testforservice.validateUserID("Narendra Modi");
		} catch (UserIDexception e) {
			t=true;
		}
		assertTrue(t);
	}
	@Test
	public void testforUserID2() {
		boolean t=false;
			try {
				//akshaysh UserID exist 
				//hence exception is successfully thrown
				assertTrue(testforservice.validateUserID("akshaysh"));
			} catch (UserIDexception e) {
				t=true;
			}
			assertTrue(t);
		}
	
	@Test
	public void testforUserID3() {
		
		try {
			//narendra UserID doesn't exist and is of 8 characters
			//hence exception is not thrown hence correct.
			assertTrue(testforservice.validateUserID("narendra"));
		} catch (UserIDexception e) {
			
		}
		
	}
	
	@Test
	public void testforUserPassword1() {
		boolean t=false;
		try {
			//"sachan" string is not correct type of password. 
			//hence exception is thrown hence correct.
			assertTrue(testforservice.validatePassword("sachan"));
		} catch (Passwordexception e) {t=true;}
		assertTrue(t);
	}
	
	@Test
	public void testforUserPassword2() {
		
		try {
			//"sachan.pp" string is  correct type of password. 
			//hence exception is not thrown hence correct.
			assertTrue(testforservice.validatePassword("sachan.pp"));
		} catch (Passwordexception e) {}
	}
	
	@Test
	public void testforMobileno1() {
		//7206301317 mobile number already exist for another user so correct exception is thrown 
		boolean t=false;
		try {
			assertTrue(testforservice.validateMobileno("7206301317","shubshub"));
		} catch (Mobilenoexception e) {
			t=true;
		}
		assertTrue(t);
		
	}
	
	@Test
	public void testforMobileno2() {
		//Mobile Number length is not correct hence exception is thrown
		boolean t=false;
		try {
			assertTrue(testforservice.validateMobileno("720123456","shubshub"));
		} catch (Mobilenoexception e) {
			t=true;
		}
		assertTrue(t);
		
	}
	
	@Test
	public void testforMobileno3() {
		//Mobile Number is correct and it doesn't associated with any another userID
		//so no exception thrown
		
		try {
			assertTrue(testforservice.validateMobileno("7201234564","shubshub"));
		} catch (Mobilenoexception e) {
			
		}
		
	}
	
	@Test
	public void testforAccountLogin1() {
		//Account User Name and password is correct
		//successful login
		try {
			assertTrue(testforservice.validateAccount("akshaysh", "abcd.1234"));
		} catch (UserIDexception e) {
			
		} catch (Passwordexception e) {}
		
	}
	
	@Test
	public void testforAccountLogin2() {
		//Account User Name is correct but password is not correct
		boolean t=false;
		try {
			assertTrue(!testforservice.validateAccount("akshaysh", "abcd.ghji"));
		} catch (UserIDexception e) {
			
		} catch (Passwordexception e) {
			t=true;
		}
		assertTrue(t);
		
	}
	@Test
	public void testforAccountLogin3() {
		//Account User Name is not correct or it doesn't exist
		boolean t=false;
		try {
			assertTrue(!testforservice.validateAccount("sachin12", "abcd.ghji"));
		} catch (UserIDexception e) {
			t=true;
		} catch (Passwordexception e) {
			
		}
		assertTrue(t);
		
	}
	
	
	@Test
	public void testforDeposit1() {
		//akshaysh exist and it have 100 as initial balance, 1000 is get deposited into it.
		try {
			testforservice.deposit("akshaysh", 1000);
			double balcheck=AccountDaoIMPL.userdetails.get("akshaysh").getBalance();
			assertEquals(1100,(int)balcheck);
		} catch (AmountCheckException e) {
			
		}
						
	}
	
	@Test
	public void testforDeposit2() {
		boolean t=false;
		//akshaysh exist but we can't deposit less than Rs 1.
		try {
			testforservice.deposit("akshaysh", 0);
		} catch (AmountCheckException e) {
		t=true;
		}
		assertTrue(t);
				
	}
	
	@Test
	public void testforWithdraw1() {
		
		//akshaysh exist and we can successfully withdraw 50 rupees.
		try {
			testforservice.withdraw("akshaysh", 50);
			double balcheck=AccountDaoIMPL.userdetails.get("akshaysh").getBalance();
			assertEquals(50,(int)balcheck);
		} catch (AmountCheckException e) {}
						
	}
	
	@Test
	public void testforWithdraw2() {
		boolean t=false;
		//akshaysh exist and we can't  withdraw more than initial amount.
		//hence exception is thrown
		try {
			testforservice.withdraw("akshaysh", 150);
			
		} catch (AmountCheckException e) {
			t=true;
		}
		assertTrue(t);
						
	}
	
	@Test
	public void testforTransfer1() {
		boolean t=false;
		//akshaysh exist and vaishali exist we can successfully transfer 50 rupees.
		//balance is greater than 50.
		try {
			testforservice.transfer("akshaysh", "vaishali", 50);
			double balcheck1=AccountDaoIMPL.userdetails.get("akshaysh").getBalance();
			double balcheck2=AccountDaoIMPL.userdetails.get("vaishali").getBalance();
			if(50==balcheck1&&150==balcheck2)
			{
				t=true;
			}
			else t=false;


		} catch (AmountCheckException e) {} catch (UserIDexception e) {
			
		}
		assertTrue(t);
						
	}
	
	@Test
	public void testforTransfer2() {
		boolean t=false;
		//check123 doesn't exist and vaishali exist 
		//hence we can't  transfer 50 rupees.
	
		try {
			testforservice.transfer("akshaysh", "check123", 50);
			
		} catch (AmountCheckException e) {} catch (UserIDexception e) {
			t=true;
		}
		assertTrue(t);
						
	}
	
	@Test
	public void testforTransfer3() {
		boolean t=false;
		//akshaysh exist and vaishali exist but we can't  transfer 1000 rupees.
		//as balance is 100.
		try {
			testforservice.transfer("akshaysh", "vaishali", 1000);
			
		} catch (AmountCheckException e) {t=true;} 
		catch (UserIDexception e) {
			
		}
		assertTrue(t);
						
	}
	
	@Test
	public void testforShowBalance1() {
	
		//akshaysh exist and balance is 100 hence successfully running.
		
			
		int balcheck=(int) AccountDaoIMPL.userdetails.get("akshaysh").getBalance();	
		
		assertEquals(100,balcheck);
						
	}
	
	@Test
	public void testforPrintTransactions() {
		
		//akshaysh exist and initial balance is 100 
		//other arraylist is created and checked.
		
		ArrayList<String> checkarraylist = new ArrayList<>();
		checkarraylist.add("Deposited Rs. "+100.0);
		try {
			testforservice.withdraw("akshaysh", 50);
			checkarraylist.add("Withdrawn Rs. "+50.0);
		} catch (AmountCheckException e) {}
		
		try {
			testforservice.deposit("akshaysh", 150);
			checkarraylist.add("Deposited Rs. "+150.0);
		} catch (AmountCheckException e) {}
		try {
			testforservice.transfer("akshaysh", "vaishali", 10);
			checkarraylist.add("Transferred Rs. "+10.0);
		} catch (AmountCheckException e) {} 
		catch (UserIDexception e) {	}
		
		assertTrue(checkarraylist.equals(AccountDaoIMPL.userdetails.get("akshaysh").transaction()));
						
	}
	
	

}
